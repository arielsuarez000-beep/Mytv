import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { C } from './theme';
import { Pressable } from './Focus';
import Card from './Card';
import { getItemsCached } from './xtream';
import { useTv } from './tv';

export default function GridScreen({ creds, kind, title, catId, search, onBack, open }) {
  const { width } = useWindowDimensions();
  const tv = useTv();
  const z = tv ? 1.4 : 1;
  const [items, setItems] = useState(null);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');

  useEffect(() => {
    let alive = true;
    getItemsCached(creds, kind, search ? null : catId)
      .then((l) => alive && setItems(l))
      .catch((e) => alive && setError(e.message));
    return () => {
      alive = false;
    };
  }, [kind, catId, search]);

  const shown = useMemo(() => {
    if (!items) return [];
    const q = query.trim().toLowerCase();
    if (search) {
      if (q.length < 2) return [];
      return items.filter((i) => (i.name || '').toLowerCase().includes(q)).slice(0, 300);
    }
    return q ? items.filter((i) => (i.name || '').toLowerCase().includes(q)) : items;
  }, [items, query, search]);

  const cols = Math.max(3, Math.floor(width / (125 * z)));
  const cw = Math.floor((width - 16 - cols * 8) / cols);

  return (
    <View style={s.root}>
      <View style={s.bar}>
        <Pressable onPress={onBack} hitSlop={12}>
          <Text style={s.back}>‹ Volver</Text>
        </Pressable>
        <Text style={s.title} numberOfLines={1}>
          {title}
        </Text>
      </View>

      <TextInput
        style={s.search}
        value={query}
        onChangeText={setQuery}
        placeholder={search ? 'Buscar en toda la lista' : 'Buscar en esta categoría'}
        placeholderTextColor={C.dim}
        autoCapitalize="none"
        autoCorrect={false}
        autoFocus={!!search}
      />

      {error ? (
        <Text style={s.msg}>{error}</Text>
      ) : !items ? (
        <View style={{ marginTop: 40 }}>
          <ActivityIndicator color={C.accent} />
          {search && <Text style={s.msg}>Cargando la lista completa…</Text>}
        </View>
      ) : search && query.trim().length < 2 ? (
        <Text style={s.msg}>Escribí al menos 2 letras para buscar.</Text>
      ) : shown.length === 0 ? (
        <Text style={s.msg}>No hay resultados.</Text>
      ) : (
        <FlatList
          key={cols}
          numColumns={cols}
          data={shown}
          keyExtractor={(i, n) => String(i.stream_id || i.series_id || n)}
          contentContainerStyle={{ paddingHorizontal: 8, paddingBottom: 30 }}
          keyboardShouldPersistTaps="handled"
          initialNumToRender={18}
          windowSize={7}
          renderItem={({ item, index }) => (
            <View style={{ margin: 4 }}>
              <Card kind={kind} item={item} width={cw} onPress={() => open(item, shown, index)} />
            </View>
          )}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingTop: 44 },
  bar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 8 },
  back: { color: C.accent, fontSize: 16, fontWeight: '600', marginRight: 14 },
  title: { color: C.text, fontSize: 18, fontWeight: '700', flex: 1 },
  search: {
    backgroundColor: C.panel,
    color: C.text,
    borderRadius: 10,
    marginHorizontal: 12,
    marginBottom: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
  },
  msg: { color: C.dim, textAlign: 'center', marginTop: 20, paddingHorizontal: 24 },
});
