import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { C } from './theme';
import { episodeUrl, getSeriesInfo } from './xtream';

export default function SeriesScreen({ creds, item, onBack, onPlay }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    getSeriesInfo(creds, item.series_id)
      .then((d) => {
        if (!alive) return;
        const eps = d && typeof d.episodes === 'object' && !Array.isArray(d.episodes) ? d.episodes : {};
        const out = [];
        Object.keys(eps)
          .sort((a, b) => Number(a) - Number(b))
          .forEach((season) => {
            out.push({ header: true, key: 'h' + season, title: `Temporada ${season}` });
            (eps[season] || []).forEach((e) => out.push({ key: 'e' + e.id, ep: e }));
          });
        setRows(out);
        setLoading(false);
      })
      .catch((e) => {
        if (!alive) return;
        setError(e.message);
        setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [item.series_id]);

  const play = (e) =>
    onPlay({
      title: `${item.name} · ${e.title || 'Episodio ' + e.episode_num}`,
      live: false,
      sources: [episodeUrl(creds, e.id, e.container_extension)],
    });

  return (
    <View style={s.root}>
      <View style={s.bar}>
        <Pressable onPress={onBack} hitSlop={12}>
          <Text style={s.back}>‹ Volver</Text>
        </Pressable>
      </View>
      <Text style={s.title} numberOfLines={2}>
        {item.name}
      </Text>
      {loading ? (
        <ActivityIndicator color={C.accent} style={{ marginTop: 40 }} />
      ) : error ? (
        <Text style={s.msg}>{error}</Text>
      ) : rows.length === 0 ? (
        <Text style={s.msg}>Esta serie no tiene episodios disponibles.</Text>
      ) : (
        <FlatList
          data={rows}
          keyExtractor={(r) => r.key}
          renderItem={({ item: r }) =>
            r.header ? (
              <Text style={s.season}>{r.title}</Text>
            ) : (
              <Pressable style={s.ep} onPress={() => play(r.ep)} android_ripple={{ color: C.line }}>
                <Text style={s.epNum}>{r.ep.episode_num}</Text>
                <Text style={s.epTitle} numberOfLines={2}>
                  {r.ep.title || 'Episodio ' + r.ep.episode_num}
                </Text>
              </Pressable>
            )
          }
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingTop: 44 },
  bar: { paddingHorizontal: 12, paddingVertical: 8 },
  back: { color: C.accent, fontSize: 16, fontWeight: '600' },
  title: { color: C.text, fontSize: 22, fontWeight: '700', paddingHorizontal: 16, marginBottom: 8 },
  season: { color: C.accent, fontSize: 15, fontWeight: '700', paddingHorizontal: 16, paddingTop: 18, paddingBottom: 6 },
  ep: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.line,
  },
  epNum: { color: C.dim, width: 34, fontSize: 15 },
  epTitle: { color: C.text, fontSize: 15, flex: 1 },
  msg: { color: C.dim, textAlign: 'center', marginTop: 40, paddingHorizontal: 24 },
});
