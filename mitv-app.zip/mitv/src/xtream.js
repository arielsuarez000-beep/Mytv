import { Platform } from 'react-native';

const enc = encodeURIComponent;

// Acepta "http://host:puerto" o una URL completa tipo get.php?username=..&password=..
export function parseInput(server, user, pass) {
  let s = (server || '').trim();
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  const m = s.match(/^(https?:\/\/[^\/?#]+)/i);
  if (!m) throw new Error('El servidor no es válido');
  const u = s.match(/[?&]username=([^&#]+)/i);
  const p = s.match(/[?&]password=([^&#]+)/i);
  return {
    base: m[1],
    username: u ? decodeURIComponent(u[1]) : (user || '').trim(),
    password: p ? decodeURIComponent(p[1]) : (pass || '').trim(),
  };
}

async function api(c, action, params = {}) {
  let q = `username=${enc(c.username)}&password=${enc(c.password)}`;
  if (action) q += `&action=${action}`;
  Object.keys(params).forEach((k) => {
    q += `&${k}=${enc(params[k])}`;
  });
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 20000);
  try {
    const r = await fetch(`${c.base}/player_api.php?${q}`, { signal: ctrl.signal });
    if (!r.ok) throw new Error(`El servidor respondió ${r.status}`);
    return await r.json();
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('El servidor tardó demasiado en responder');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

export async function login(c) {
  const d = await api(c, '');
  const ok = d && d.user_info && String(d.user_info.auth) === '1';
  if (!ok) throw new Error('Usuario o contraseña incorrectos');
  return d;
}

const CAT = { live: 'get_live_categories', vod: 'get_vod_categories', series: 'get_series_categories' };
const ITEMS = { live: 'get_live_streams', vod: 'get_vod_streams', series: 'get_series' };

export async function getCategories(c, kind) {
  const a = await api(c, CAT[kind]);
  return Array.isArray(a) ? a : [];
}

export async function getItems(c, kind, catId) {
  const a = await api(c, ITEMS[kind], catId ? { category_id: String(catId) } : {});
  return Array.isArray(a) ? a : [];
}

export function getSeriesInfo(c, id) {
  return api(c, 'get_series_info', { series_id: String(id) });
}

// En Android se prueba primero el flujo directo .ts (más estable en vivo)
// y el HLS .m3u8 queda de respaldo. En iPhone solo funciona HLS.
export function liveSources(c, id) {
  const b = `${c.base}/live/${enc(c.username)}/${enc(c.password)}/${id}`;
  return Platform.OS === 'android' ? [`${b}.ts`, `${b}.m3u8`] : [`${b}.m3u8`];
}

export function movieUrl(c, id, ext) {
  return `${c.base}/movie/${enc(c.username)}/${enc(c.password)}/${id}.${ext || 'mp4'}`;
}

export function episodeUrl(c, id, ext) {
  return `${c.base}/series/${enc(c.username)}/${enc(c.password)}/${id}.${ext || 'mp4'}`;
}
