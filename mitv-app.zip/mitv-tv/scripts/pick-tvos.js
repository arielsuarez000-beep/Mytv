// Elige la última versión de react-native-tvos de la serie 0.81 (la que corresponde a Expo SDK 54)
// y la última de @react-native-tvos/config-tv, y las escribe en package.json.
const fs = require('fs');
const { execSync } = require('child_process');

function pick(versions) {
  const ok = versions
    .map((v) => {
      const m = /^0\.81\.(\d+)-(\d+)$/.exec(v);
      return m ? { v, patch: +m[1], pre: +m[2] } : null;
    })
    .filter(Boolean)
    .sort((a, b) => a.patch - b.patch || a.pre - b.pre);
  return ok.length ? ok[ok.length - 1].v : null;
}

function npmJson(args) {
  return JSON.parse(execSync('npm view ' + args + ' --json', { encoding: 'utf8' }));
}

if (require.main === module) {
  const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
  try {
    const best = pick(npmJson('react-native-tvos versions'));
    if (best) {
      pkg.dependencies['react-native'] = 'npm:react-native-tvos@' + best;
      console.log('react-native-tvos ->', best);
    } else {
      console.log('No se encontró 0.81.x; se deja', pkg.dependencies['react-native']);
    }
  } catch (e) {
    console.log('No se pudo consultar npm (react-native-tvos):', e.message);
  }
  try {
    const cfg = npmJson('@react-native-tvos/config-tv version');
    pkg.dependencies['@react-native-tvos/config-tv'] = '^' + cfg;
    console.log('config-tv ->', cfg);
  } catch (e) {
    console.log('No se pudo consultar npm (config-tv):', e.message);
  }
  fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2));
}
module.exports = { pick };
