import React, { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import { C } from './theme';

const STALL_SECONDS = 9; // segundos sin avanzar antes de reconectar
const FIRST_LOAD_SECONDS = 15; // más margen mientras arranca el canal

export default function PlayerScreen({ sources, live, title, onBack }) {
  const [info, setInfo] = useState('Cargando…');
  const idxRef = useRef(0);
  const badRef = useRef(0); // fallos seguidos (errores o congelamientos)
  const stallRef = useRef(0);
  const lastTimeRef = useRef(-1);
  const lastReloadRef = useRef(0);
  const loadRef = useRef(null);
  const problemRef = useRef(null);

  const player = useVideoPlayer(sources[0], (p) => {
    p.play();
  });

  loadRef.current = (i) => {
    idxRef.current = i;
    stallRef.current = 0;
    lastTimeRef.current = -1;
    try {
      player.replace(sources[i]);
      player.play();
    } catch {}
  };

  problemRef.current = () => {
    badRef.current += 1;
    lastReloadRef.current = Date.now();
    if (live && sources.length > 1 && badRef.current >= 3) {
      // Después de 3 fallos, alterna entre .ts y .m3u8
      badRef.current = 0;
      setInfo('Probando otro formato…');
      loadRef.current((idxRef.current + 1) % sources.length);
    } else if (live || badRef.current <= 3) {
      setInfo('Reconectando…');
      setTimeout(() => loadRef.current(idxRef.current), 1000);
    } else {
      setInfo('No se puede reproducir este video');
    }
  };

  useEffect(() => {
    const sub = player.addListener('statusChange', ({ status }) => {
      if (status === 'readyToPlay') setInfo('');
      else if (status === 'loading') setInfo((v) => v || 'Cargando…');
      else if (status === 'error') problemRef.current();
    });
    return () => sub.remove();
  }, [player]);

  // Vigilante: si la imagen no avanza, recarga el canal solo (solo en vivo)
  useEffect(() => {
    if (!live) return undefined;
    const id = setInterval(() => {
      try {
        if (!player.playing) {
          stallRef.current = 0;
          return;
        }
        const t = player.currentTime;
        if (t !== lastTimeRef.current) {
          lastTimeRef.current = t;
          stallRef.current = 0;
          if (t > 0 && Date.now() - lastReloadRef.current > 30000) badRef.current = 0;
        } else {
          stallRef.current += 1;
          const limit = lastTimeRef.current <= 0 ? FIRST_LOAD_SECONDS : STALL_SECONDS;
          if (stallRef.current >= limit) {
            stallRef.current = 0;
            problemRef.current();
          }
        }
      } catch {}
    }, 1000);
    return () => clearInterval(id);
  }, [player, live]);

  return (
    <View style={s.root}>
      <View style={s.bar}>
        <Pressable onPress={onBack} hitSlop={12}>
          <Text style={s.back}>‹ Volver</Text>
        </Pressable>
        <Text style={s.title} numberOfLines={1}>
          {title}
        </Text>
      </View>
      <View style={s.videoBox}>
        <VideoView
          player={player}
          style={StyleSheet.absoluteFill}
          nativeControls
          allowsFullscreen
          contentFit="contain"
        />
        {!!info && (
          <View style={s.badge} pointerEvents="none">
            <Text style={s.badgeText}>{info}</Text>
          </View>
        )}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000', paddingTop: 36 },
  bar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8 },
  back: { color: C.accent, fontSize: 16, fontWeight: '600', marginRight: 14 },
  title: { color: C.text, fontSize: 15, flex: 1 },
  videoBox: { flex: 1, backgroundColor: '#000' },
  badge: {
    position: 'absolute',
    left: 12,
    bottom: 64,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  badgeText: { color: C.text, fontSize: 13 },
});
