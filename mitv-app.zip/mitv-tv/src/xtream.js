import { Platform } from 'react-native';

const enc = encodeURIComponent;

// Acepta "http://host:puerto" o una URL completa tipo get.php?username=..&password=..
export function parseInput(server, user, pass) {
  let s = (server || '').trim();
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  const m = s.match(/^(https?:\/\/[^\/?#]+)/i);
  if (!m) throw new Error('El servidor no es válido');
  const u = s.match(/[?&]username=([^&#]+)/i);
  const p = s.match(/[?&]password=([^&#]+)/i);
  return {
    base: m[1],
    username: u ? decodeURIComponent(u[1]) : (user || '').trim(),
    password: p ? decodeURIComponent(p[1]) : (pass || '').trim(),
  };
}

async function api(c, action, params = {}, timeout = 20000) {
  let q = `username=${enc(c.username)}&password=${enc(c.password)}`;
  if (action) q += `&action=${action}`;
  Object.keys(params).forEach((k) => {
    q += `&${k}=${enc(params[k])}`;
  });
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    const r = await fetch(`${c.base}/player_api.php?${q}`, { signal: ctrl.signal });
    if (!r.ok) throw new Error(`El servidor respondió ${r.status}`);
    return await r.json();
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('El servidor tardó demasiado en responder');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

export async function login(c) {
  // Prueba 1: consulta de acceso (sin "action")
  let first;
  try {
    const d = await api(c, '');
    if (d && d.user_info) {
      if (String(d.user_info.auth) === '1') return d;
      throw new Error('Usuario o contraseña incorrectos');
    }
    first = new Error('respuesta inesperada');
  } catch (e) {
    if (e.message === 'Usuario o contraseña incorrectos') throw e;
    first = e;
  }
  // Prueba 2: la misma consulta que usa flark.tv (lista de categorías)
  try {
    const cats = await api(c, 'get_live_categories');
    if (Array.isArray(cats) && cats.length > 0) return { user_info: { auth: 1 } };
    throw new Error('EMPTY');
  } catch (e2) {
    if (e2.message === 'EMPTY') {
      throw new Error('El servidor respondió, pero sin canales. Revisá el usuario y la contraseña.');
    }
    const host = c.base.replace(/^https?:\/\//, '');
    throw new Error(`No se pudo conectar a ${host}\nDetalle: ${first.message} / ${e2.message}`);
  }
}

const CAT = { live: 'get_live_categories', vod: 'get_vod_categories', series: 'get_series_categories' };
const ITEMS = { live: 'get_live_streams', vod: 'get_vod_streams', series: 'get_series' };

async function getCategories(c, kind) {
  const a = await api(c, CAT[kind]);
  return Array.isArray(a) ? a : [];
}

async function getItems(c, kind, catId) {
  const a = catId
    ? await api(c, ITEMS[kind], { category_id: String(catId) })
    : await api(c, ITEMS[kind], {}, 90000); // lista completa: puede tardar
  return Array.isArray(a) ? a : [];
}

// Caché en memoria para no repetir pedidos al proveedor
const cache = new Map();
function cached(key, fn) {
  if (!cache.has(key)) {
    const p = fn().catch((e) => {
      cache.delete(key);
      throw e;
    });
    cache.set(key, p);
  }
  return cache.get(key);
}

export function getCategoriesCached(c, kind) {
  return cached(`${c.base}|${c.username}|cat|${kind}`, () => getCategories(c, kind));
}

export function getItemsCached(c, kind, catId) {
  const id = catId == null ? 'all' : catId;
  return cached(`${c.base}|${c.username}|items|${kind}|${id}`, () => getItems(c, kind, catId));
}

export function clearCache() {
  cache.clear();
}

export function getSeriesInfo(c, id) {
  return api(c, 'get_series_info', { series_id: String(id) });
}

// Se prueba primero HLS (.m3u8), que en las pruebas anduvo más fluido, y el flujo
// directo .ts queda de respaldo (y se puede alternar a mano en el reproductor).
// En iPhone solo funciona HLS.
export function liveSources(c, id) {
  const b = `${c.base}/live/${enc(c.username)}/${enc(c.password)}/${id}`;
  return Platform.OS === 'android' ? [`${b}.m3u8`, `${b}.ts`] : [`${b}.m3u8`];
}

export function movieUrl(c, id, ext) {
  return `${c.base}/movie/${enc(c.username)}/${enc(c.password)}/${id}.${ext || 'mp4'}`;
}

export function episodeUrl(c, id, ext) {
  return `${c.base}/series/${enc(c.username)}/${enc(c.password)}/${id}.${ext || 'mp4'}`;
}
