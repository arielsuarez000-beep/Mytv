import React, { useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { C } from './theme';
import { login, parseInput } from './xtream';

export default function SetupScreen({ onDone }) {
  const [server, setServer] = useState('');
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    setError('');
    setBusy(true);
    try {
      const c = parseInput(server, user, pass);
      if (!c.username || !c.password) throw new Error('Falta el usuario o la contraseña');
      await login(c);
      await onDone(c);
    } catch (e) {
      setError(e.message || 'No se pudo conectar');
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: C.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={s.wrap} keyboardShouldPersistTaps="handled">
        <Text style={s.title}>MiTV</Text>
        <Text style={s.sub}>Conectá tu lista para ver canales, películas y series.</Text>

        <Text style={s.label}>Servidor o URL de la lista</Text>
        <TextInput
          style={s.input}
          value={server}
          onChangeText={setServer}
          placeholder="http://servidor.com:8080"
          placeholderTextColor={C.dim}
          autoCapitalize="none"
          autoCorrect={false}
        />
        <Text style={s.hint}>
          Si pegás la URL completa de la lista (la que tiene username= y password=), no hace falta llenar usuario y contraseña.
        </Text>

        <Text style={s.label}>Usuario</Text>
        <TextInput
          style={s.input}
          value={user}
          onChangeText={setUser}
          autoCapitalize="none"
          autoCorrect={false}
          placeholderTextColor={C.dim}
        />

        <Text style={s.label}>Contraseña</Text>
        <TextInput
          style={s.input}
          value={pass}
          onChangeText={setPass}
          autoCapitalize="none"
          autoCorrect={false}
          secureTextEntry
          placeholderTextColor={C.dim}
        />

        {!!error && <Text style={s.error}>{error}</Text>}

        <Pressable style={[s.btn, busy && { opacity: 0.6 }]} onPress={submit} disabled={busy}>
          {busy ? <ActivityIndicator color="#1a1206" /> : <Text style={s.btnText}>Conectar</Text>}
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  wrap: { padding: 24, paddingTop: 72 },
  title: { color: C.accent, fontSize: 40, fontWeight: '800', letterSpacing: 0.5 },
  sub: { color: C.dim, fontSize: 15, marginTop: 6, marginBottom: 28 },
  label: { color: C.text, fontSize: 14, fontWeight: '600', marginTop: 14, marginBottom: 6 },
  input: {
    backgroundColor: C.panel,
    borderColor: C.line,
    borderWidth: 1,
    borderRadius: 10,
    color: C.text,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
  },
  hint: { color: C.dim, fontSize: 12, marginTop: 6, lineHeight: 17 },
  error: { color: C.danger, marginTop: 16, fontSize: 14 },
  btn: {
    backgroundColor: C.accent,
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 26,
  },
  btnText: { color: '#1a1206', fontSize: 16, fontWeight: '700' },
});
