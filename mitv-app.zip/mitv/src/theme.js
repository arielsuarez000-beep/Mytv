export const C = {
  bg: '#0B1418',
  panel: '#142229',
  line: '#22353d',
  text: '#EAF1F3',
  dim: '#8EA3AB',
  accent: '#F2A541',
  danger: '#E5675B',
};
