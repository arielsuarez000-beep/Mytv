import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, BackHandler, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { clearCreds, loadCreds, saveCreds } from './src/storage';
import { clearCache } from './src/xtream';
import { makeOpen } from './src/open';
import { loadTvMode } from './src/tv';
import { C } from './src/theme';
import SetupScreen from './src/SetupScreen';
import BrowseScreen from './src/BrowseScreen';
import GridScreen from './src/GridScreen';
import SeriesScreen from './src/SeriesScreen';
import PlayerScreen from './src/PlayerScreen';

export default function App() {
  const [creds, setCreds] = useState(undefined); // undefined = cargando, null = sin sesión
  const [stack, setStack] = useState([]);
  const stackRef = useRef([]);
  const idRef = useRef(0);
  stackRef.current = stack;

  useEffect(() => {
    Promise.all([loadCreds(), loadTvMode()]).then(([c]) => setCreds(c || null));
  }, []);

  const push = useCallback((entry) => {
    idRef.current += 1;
    const id = idRef.current;
    setStack((st) => [...st, { ...entry, id }]);
  }, []);
  const pop = useCallback(() => setStack((st) => st.slice(0, -1)), []);

  const onPlay = useCallback((p) => push({ type: 'player', ...p }), [push]);
  const onSeries = useCallback((item) => push({ type: 'series', item }), [push]);
  const onGrid = useCallback((g) => push({ type: 'grid', ...g }), [push]);

  // Se registra una sola vez, así el reproductor puede atender "atrás" antes (pantalla completa)
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (stackRef.current.length) {
        pop();
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [pop]);

  if (creds === undefined) {
    return (
      <View style={{ flex: 1, backgroundColor: C.bg, justifyContent: 'center' }}>
        <ActivityIndicator color={C.accent} size="large" />
      </View>
    );
  }

  if (!creds) {
    return (
      <>
        <StatusBar style="light" />
        <SetupScreen
          onDone={async (c) => {
            await saveCreds(c);
            setCreds(c);
          }}
        />
      </>
    );
  }

  const hasTop = stack.length > 0;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style="light" />

      <View style={{ flex: 1, display: hasTop ? 'none' : 'flex' }}>
        <BrowseScreen
          creds={creds}
          onPlay={onPlay}
          onSeries={onSeries}
          onGrid={onGrid}
          onLogout={async () => {
            await clearCreds();
            clearCache();
            setStack([]);
            setCreds(null);
          }}
        />
      </View>

      {stack.map((e, i) => {
        const isTop = i === stack.length - 1;
        return (
          <View key={e.id} style={{ flex: 1, display: isTop ? 'flex' : 'none' }}>
            {e.type === 'grid' && (
              <GridScreen
                creds={creds}
                kind={e.kind}
                title={e.title}
                catId={e.catId}
                search={e.search}
                onBack={pop}
                open={makeOpen(creds, e.kind, onPlay, onSeries)}
              />
            )}
            {e.type === 'series' && (
              <SeriesScreen creds={creds} item={e.item} onBack={pop} onPlay={onPlay} />
            )}
            {e.type === 'player' && (
              <PlayerScreen
                creds={creds}
                live={e.live}
                title={e.title}
                sources={e.sources}
                channels={e.channels}
                index={e.index}
                onBack={pop}
              />
            )}
          </View>
        );
      })}
    </View>
  );
}
