import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { C } from './theme';
import { getCategories, getItems, liveSources, movieUrl } from './xtream';

const TABS = [
  ['live', 'TV en vivo'],
  ['vod', 'Películas'],
  ['series', 'Series'],
];

export default function BrowseScreen({ creds, onPlay, onSeries, onLogout }) {
  const [tab, setTab] = useState('live');
  const [cats, setCats] = useState([]);
  const [catId, setCatId] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const token = useRef(0);

  useEffect(() => {
    const t = ++token.current;
    setCats([]);
    setCatId(null);
    setItems([]);
    setQuery('');
    setError('');
    setLoading(true);
    getCategories(creds, tab)
      .then((list) => {
        if (t !== token.current) return;
        setCats(list);
        if (list.length) setCatId(list[0].category_id);
        else setLoading(false);
      })
      .catch((e) => {
        if (t !== token.current) return;
        setError(e.message);
        setLoading(false);
      });
  }, [tab, creds]);

  useEffect(() => {
    if (catId == null) return;
    const t = ++token.current;
    setLoading(true);
    setError('');
    getItems(creds, tab, catId)
      .then((list) => {
        if (t !== token.current) return;
        setItems(list);
        setLoading(false);
      })
      .catch((e) => {
        if (t !== token.current) return;
        setError(e.message);
        setLoading(false);
      });
  }, [catId]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? items.filter((i) => (i.name || '').toLowerCase().includes(q)) : items;
  }, [items, query]);

  const open = (item) => {
    if (tab === 'live') {
      onPlay({ title: item.name, live: true, sources: liveSources(creds, item.stream_id) });
    } else if (tab === 'vod') {
      onPlay({
        title: item.name,
        live: false,
        sources: [movieUrl(creds, item.stream_id, item.container_extension)],
      });
    } else {
      onSeries(item);
    }
  };

  const renderItem = ({ item }) => {
    const img = item.stream_icon || item.cover;
    return (
      <Pressable style={s.row} onPress={() => open(item)} android_ripple={{ color: C.line }}>
        {img ? (
          <Image source={{ uri: img }} style={s.logo} resizeMode="contain" />
        ) : (
          <View style={s.logo} />
        )}
        <Text style={s.name} numberOfLines={2}>
          {item.name}
        </Text>
      </Pressable>
    );
  };

  return (
    <View style={s.root}>
      <View style={s.top}>
        <View style={s.tabs}>
          {TABS.map(([k, label]) => (
            <Pressable key={k} onPress={() => setTab(k)} style={[s.tab, tab === k && s.tabOn]}>
              <Text style={[s.tabText, tab === k && s.tabTextOn]}>{label}</Text>
            </Pressable>
          ))}
        </View>
        <Pressable onPress={onLogout} hitSlop={10}>
          <Text style={s.logout}>Salir</Text>
        </Pressable>
      </View>

      <FlatList
        horizontal
        data={cats}
        keyExtractor={(c) => String(c.category_id)}
        showsHorizontalScrollIndicator={false}
        style={s.cats}
        contentContainerStyle={{ paddingHorizontal: 12 }}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => setCatId(item.category_id)}
            style={[s.chip, catId === item.category_id && s.chipOn]}
          >
            <Text style={[s.chipText, catId === item.category_id && s.chipTextOn]} numberOfLines={1}>
              {item.category_name}
            </Text>
          </Pressable>
        )}
      />

      <TextInput
        style={s.search}
        value={query}
        onChangeText={setQuery}
        placeholder="Buscar en esta categoría"
        placeholderTextColor={C.dim}
        autoCapitalize="none"
        autoCorrect={false}
      />

      {loading ? (
        <ActivityIndicator color={C.accent} style={{ marginTop: 40 }} />
      ) : error ? (
        <Text style={s.msg}>{error}</Text>
      ) : shown.length === 0 ? (
        <Text style={s.msg}>No hay resultados.</Text>
      ) : (
        <FlatList
          data={shown}
          keyExtractor={(i, n) => String(i.stream_id || i.series_id || n)}
          renderItem={renderItem}
          initialNumToRender={20}
          windowSize={7}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingTop: 44 },
  top: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12 },
  tabs: { flexDirection: 'row', flex: 1 },
  tab: { paddingVertical: 8, paddingHorizontal: 12, marginRight: 4 },
  tabOn: { borderBottomWidth: 2, borderBottomColor: C.accent },
  tabText: { color: C.dim, fontSize: 15, fontWeight: '600' },
  tabTextOn: { color: C.text },
  logout: { color: C.dim, fontSize: 13 },
  cats: { flexGrow: 0, marginTop: 10 },
  chip: {
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingVertical: 7,
    marginRight: 8,
    maxWidth: 220,
  },
  chipOn: { backgroundColor: C.accent, borderColor: C.accent },
  chipText: { color: C.dim, fontSize: 13 },
  chipTextOn: { color: '#1a1206', fontWeight: '700' },
  search: {
    backgroundColor: C.panel,
    color: C.text,
    borderRadius: 10,
    marginHorizontal: 12,
    marginVertical: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.line,
  },
  logo: { width: 52, height: 52, borderRadius: 8, backgroundColor: C.panel, marginRight: 12 },
  name: { color: C.text, fontSize: 15, flex: 1 },
  msg: { color: C.dim, textAlign: 'center', marginTop: 40, paddingHorizontal: 24 },
});
