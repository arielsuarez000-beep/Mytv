import React, { useState } from 'react';
import { Pressable as RNPressable } from 'react-native';
import { C } from './theme';

// Igual que Pressable, pero se puede seleccionar con el control remoto (flechas)
// y muestra un borde de color en el elemento seleccionado.
const FOCUS = { outlineWidth: 3, outlineColor: C.accent, outlineOffset: 2 };

export function Pressable({ style, onFocus, onBlur, ...rest }) {
  const [focused, setFocused] = useState(false);
  return (
    <RNPressable
      focusable
      {...rest}
      onFocus={(e) => {
        setFocused(true);
        if (onFocus) onFocus(e);
      }}
      onBlur={(e) => {
        setFocused(false);
        if (onBlur) onBlur(e);
      }}
      style={[style, focused && FOCUS]}
    />
  );
}
