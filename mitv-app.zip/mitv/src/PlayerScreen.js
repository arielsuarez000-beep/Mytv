import React, { useEffect, useRef, useState } from 'react';
import {
  BackHandler,
  FlatList,
  Image,
  PanResponder,
  StatusBar as RNStatusBar,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useVideoPlayer, VideoView } from 'expo-video';
import * as ScreenOrientation from 'expo-screen-orientation';
import * as NavigationBar from 'expo-navigation-bar';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { C } from './theme';
import { Pressable } from './Focus';
import { liveSources } from './xtream';
import { useTv } from './tv';

const STALL_SECONDS = 9; // segundos sin avanzar antes de reconectar
const FIRST_LOAD_SECONDS = 15; // más margen mientras arranca el canal
const ROW_H = 64;

// Ejecuta algo que puede no estar soportado en algún teléfono, sin romper la app
function safe(fn) {
  try {
    const r = fn();
    if (r && typeof r.catch === 'function') r.catch(() => {});
  } catch {}
}

function enterFullscreen() {
  safe(() => ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE));
}

function exitFullscreen() {
  safe(() => ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP));
  setTimeout(() => safe(() => ScreenOrientation.unlockAsync()), 700);
}

function Pill({ label, onPress, onFocus }) {
  return (
    <Pressable style={s.pill} onPress={onPress} onFocus={onFocus} hitSlop={6}>
      <Text style={s.pillText}>{label}</Text>
    </Pressable>
  );
}

export default function PlayerScreen({ creds, live, title, sources, channels, index, onBack }) {
  const { width, height } = useWindowDimensions();
  const full = width > height; // horizontal = pantalla completa
  const tv = useTv();
  const tvRef = useRef(tv);
  tvRef.current = tv;
  const start = index || 0;
  const hasList = !!(live && channels && channels.length);

  const [ci, setCi] = useState(start);
  const [info, setInfo] = useState('Cargando…');
  const [ui, setUi] = useState(true);
  const [fmt, setFmt] = useState(0); // 0 = .ts directo, 1 = HLS (.m3u8)

  const initial = hasList ? liveSources(creds, channels[start].stream_id) : sources;
  const srcRef = useRef(initial);
  const ciRef = useRef(start);
  const idxRef = useRef(0);
  const prefRef = useRef(0); // formato elegido a mano, se mantiene al cambiar de canal
  const badRef = useRef(0); // fallos seguidos (errores o congelamientos)
  const stallRef = useRef(0);
  const lastTimeRef = useRef(-1);
  const lastReloadRef = useRef(0);
  const hideTimer = useRef(null);
  const listRef = useRef(null);
  const fullRef = useRef(full);
  const uiRef = useRef(true);
  const loadRef = useRef(null);
  const problemRef = useRef(null);
  const goRef = useRef(null);
  const showUiRef = useRef(null);
  fullRef.current = full;
  uiRef.current = ui;

  const player = useVideoPlayer(initial[0], (p) => {
    // Más colchón de video para aguantar cortes cortos de la señal
    safe(() => {
      p.bufferOptions = {
        preferredForwardBufferDuration: 30,
        minBufferForPlayback: 4,
        prioritizeTimeOverSizeThreshold: true,
        waitsToMinimizeStalling: true,
      };
    });
    p.play();
  });

  loadRef.current = (i) => {
    idxRef.current = i;
    setFmt(i);
    stallRef.current = 0;
    lastTimeRef.current = -1;
    safe(() => {
      player.replace(srcRef.current[i]);
      player.play();
    });
  };

  problemRef.current = () => {
    badRef.current += 1;
    lastReloadRef.current = Date.now();
    const n = srcRef.current.length;
    if (live && n > 1 && badRef.current >= 3) {
      // Después de 3 fallos, alterna entre .ts y .m3u8
      badRef.current = 0;
      setInfo('Probando otro formato…');
      loadRef.current((idxRef.current + 1) % n);
    } else if (live || badRef.current <= 3) {
      setInfo('Reconectando…');
      setTimeout(() => loadRef.current(idxRef.current), 1000);
    } else {
      setInfo('No se puede reproducir este video');
    }
  };

  showUiRef.current = () => {
    setUi(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setUi(false), 4000);
  };

  // Cambiar a otro canal de la lista
  goRef.current = (next) => {
    if (!hasList || next === ciRef.current) return;
    ciRef.current = next;
    setCi(next);
    srcRef.current = liveSources(creds, channels[next].stream_id);
    idxRef.current = Math.min(prefRef.current, srcRef.current.length - 1);
    setFmt(idxRef.current);
    badRef.current = 0;
    stallRef.current = 0;
    lastTimeRef.current = -1;
    setInfo('Cargando…');
    safe(() => {
      player.replace(srcRef.current[idxRef.current]);
      player.play();
    });
    showUiRef.current();
    safe(() => listRef.current && listRef.current.scrollToIndex({ index: next, viewPosition: 0.3, animated: true }));
  };

  const zap = (dir) => {
    if (!hasList || channels.length < 2) return;
    goRef.current((ciRef.current + dir + channels.length) % channels.length);
  };
  const zapRef = useRef(zap);
  zapRef.current = zap;

  // Toque = mostrar/ocultar controles. Deslizar = cambiar de canal.
  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderRelease: (_, g) => {
        const ax = Math.abs(g.dx);
        const ay = Math.abs(g.dy);
        if (ax < 12 && ay < 12) {
          if (uiRef.current) setUi(false);
          else showUiRef.current();
          return;
        }
        if (Math.max(ax, ay) < 50) return;
        if (ay > ax) zapRef.current(g.dy < 0 ? 1 : -1);
        else zapRef.current(g.dx < 0 ? 1 : -1);
      },
    })
  ).current;

  useEffect(() => {
    const sub = player.addListener('statusChange', ({ status }) => {
      if (status === 'readyToPlay') setInfo('');
      else if (status === 'loading') setInfo((v) => v || 'Cargando…');
      else if (status === 'error') problemRef.current();
    });
    return () => sub.remove();
  }, [player]);

  // Vigilante: si la imagen no avanza, recarga el canal solo (solo en vivo)
  useEffect(() => {
    if (!live) return undefined;
    const id = setInterval(() => {
      try {
        if (!player.playing) {
          stallRef.current = 0;
          return;
        }
        const t = player.currentTime;
        if (t !== lastTimeRef.current) {
          lastTimeRef.current = t;
          stallRef.current = 0;
          if (t > 0 && Date.now() - lastReloadRef.current > 30000) badRef.current = 0;
        } else {
          stallRef.current += 1;
          const limit = lastTimeRef.current <= 0 ? FIRST_LOAD_SECONDS : STALL_SECONDS;
          if (stallRef.current >= limit) {
            stallRef.current = 0;
            problemRef.current();
          }
        }
      } catch {}
    }, 1000);
    return () => clearInterval(id);
  }, [player, live]);

  // Pantalla siempre encendida mientras se mira
  useEffect(() => {
    safe(() => activateKeepAwakeAsync('mitv-player'));
    return () => safe(() => deactivateKeepAwake('mitv-player'));
  }, []);

  // Ocultar/mostrar la barra de navegación según pantalla completa
  useEffect(() => {
    safe(() => NavigationBar.setVisibilityAsync(full ? 'hidden' : 'visible'));
  }, [full]);

  // El botón "atrás" del celular primero sale de pantalla completa
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (fullRef.current && !tvRef.current) {
        exitFullscreen();
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, []);

  // Al mostrar el reproductor por primera vez, y al salir, dejar todo como estaba
  useEffect(() => {
    showUiRef.current();
    return () => {
      clearTimeout(hideTimer.current);
      safe(() => ScreenOrientation.unlockAsync());
      safe(() => NavigationBar.setVisibilityAsync('visible'));
    };
  }, []);

  // Cambiar a mano entre .ts directo y HLS para probar cuál anda mejor
  const toggleFmt = () => {
    const n = srcRef.current.length;
    if (n < 2) return;
    const next = (idxRef.current + 1) % n;
    prefRef.current = next;
    badRef.current = 0;
    setInfo('Cargando…');
    loadRef.current(next);
    showUiRef.current();
  };
  const fmtLabel =
    srcRef.current[fmt] && srcRef.current[fmt].endsWith('.ts') ? 'Formato: TS' : 'Formato: HLS';

  const name = hasList ? channels[ci].name : title;
  const fs = () => showUiRef.current();

  return (
    <View style={[s.root, full && { paddingTop: 0 }]}>
      <RNStatusBar hidden={full} />

      {!full && (
        <View style={s.bar}>
          <Pressable onPress={onBack} hitSlop={12}>
            <Text style={s.back}>‹ Volver</Text>
          </Pressable>
          <Text style={s.title} numberOfLines={1}>
            {name}
          </Text>
        </View>
      )}

      <View style={full ? s.boxFull : s.box}>
        <VideoView
          player={player}
          style={StyleSheet.absoluteFill}
          nativeControls={!live}
          allowsFullscreen={!live}
          contentFit="contain"
        />

        {live && <View style={StyleSheet.absoluteFill} {...pan.panHandlers} />}

        {!!info && (
          <View style={s.badge} pointerEvents="none">
            <Text style={s.badgeText}>{info}</Text>
          </View>
        )}

        {live && (
          <View
            style={[StyleSheet.absoluteFill, { opacity: ui ? 1 : 0 }]}
            pointerEvents={ui ? 'box-none' : 'none'}
          >
            <View style={s.topRow} pointerEvents="box-none">
              {full && (
                <Pill
                  label={tv ? '‹ Volver' : '‹ Salir'}
                  onPress={tv ? onBack : exitFullscreen}
                  onFocus={fs}
                />
              )}
              <Text style={s.chName} numberOfLines={1} pointerEvents="none">
                {name}
              </Text>
            </View>

            {hasList && channels.length > 1 && (
              <View style={s.midRow} pointerEvents="box-none">
                <Pill label="‹ Canal" onPress={() => zap(-1)} onFocus={fs} />
                <Pill label="Canal ›" onPress={() => zap(1)} onFocus={fs} />
              </View>
            )}

            <View style={s.botRow} pointerEvents="box-none">
              {srcRef.current.length > 1 && (
                <View style={{ marginRight: 8 }}>
                  <Pill label={fmtLabel} onPress={toggleFmt} onFocus={fs} />
                </View>
              )}
              {!tv && (
                <Pill
                  label={full ? 'Reducir pantalla' : 'Pantalla completa'}
                  onPress={full ? exitFullscreen : enterFullscreen}
                  onFocus={fs}
                />
              )}
            </View>
          </View>
        )}
      </View>

      {!full && hasList && (
        <FlatList
          ref={listRef}
          data={channels}
          extraData={ci}
          keyExtractor={(c, i) => `${c.stream_id}:${i}`}
          getItemLayout={(_, i) => ({ length: ROW_H, offset: ROW_H * i, index: i })}
          initialScrollIndex={Math.min(Math.max(0, start - 2), channels.length - 1)}
          style={{ backgroundColor: C.bg }}
          renderItem={({ item, index: i }) => (
            <Pressable
              style={[s.chRow, i === ci && s.chRowOn]}
              onPress={() => goRef.current(i)}
              android_ripple={{ color: C.line }}
            >
              {item.stream_icon ? (
                <Image source={{ uri: item.stream_icon }} style={s.chLogo} resizeMode="contain" />
              ) : (
                <View style={s.chLogo} />
              )}
              <Text style={[s.chText, i === ci && { color: C.accent, fontWeight: '700' }]} numberOfLines={2}>
                {item.name}
              </Text>
              {i === ci && <Text style={s.live}>EN VIVO</Text>}
            </Pressable>
          )}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000', paddingTop: 36 },
  bar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8 },
  back: { color: C.accent, fontSize: 16, fontWeight: '600', marginRight: 14 },
  title: { color: C.text, fontSize: 15, flex: 1 },
  box: { width: '100%', aspectRatio: 16 / 9, backgroundColor: '#000' },
  boxFull: { flex: 1, backgroundColor: '#000' },
  badge: {
    position: 'absolute',
    left: 12,
    bottom: 12,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  badgeText: { color: C.text, fontSize: 13 },
  topRow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: 'rgba(0,0,0,0.35)',
  },
  chName: { color: '#fff', fontSize: 15, fontWeight: '700', flex: 1, marginLeft: 6 },
  midRow: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
  },
  botRow: { position: 'absolute', right: 12, bottom: 10, flexDirection: 'row' },
  pill: {
    backgroundColor: 'rgba(0,0,0,0.65)',
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },
  pillText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  chRow: {
    height: ROW_H,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.line,
  },
  chRowOn: { backgroundColor: C.panel },
  chLogo: { width: 44, height: 44, borderRadius: 8, backgroundColor: C.panel, marginRight: 12 },
  chText: { color: C.text, fontSize: 15, flex: 1 },
  live: { color: C.danger, fontSize: 11, fontWeight: '800', marginLeft: 8 },
});
