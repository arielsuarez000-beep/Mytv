import { useEffect, useState } from 'react';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// "Modo TV": se activa solo en Android TV y se puede forzar a mano en un TV box
// que no se identifique como televisor.
const KEY = 'mitv_tvmode';
let manual = false;
const listeners = new Set();

export function isTv() {
  return !!Platform.isTV || manual;
}

export async function loadTvMode() {
  try {
    manual = (await AsyncStorage.getItem(KEY)) === '1';
  } catch {}
  return isTv();
}

export async function setTvMode(value) {
  manual = !!value;
  listeners.forEach((f) => f());
  try {
    await AsyncStorage.setItem(KEY, manual ? '1' : '0');
  } catch {}
}

export function useTv() {
  const [v, setV] = useState(isTv());
  useEffect(() => {
    const f = () => setV(isTv());
    listeners.add(f);
    f();
    return () => listeners.delete(f);
  }, []);
  return v;
}
