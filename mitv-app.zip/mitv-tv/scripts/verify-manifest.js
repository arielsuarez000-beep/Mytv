// Se ejecuta después de "expo prebuild". Revisa el AndroidManifest generado y,
// si falta algo, lo agrega: conexión HTTP, soporte de TV box y banner.
const fs = require('fs');
const path = require('path');

const root = process.cwd();
const mf = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
let xml = fs.readFileSync(mf, 'utf8');
const notes = [];

// 1) <application>: permitir HTTP (listas sin https) y banner de TV
const appMatch = xml.match(/<application\b[^>]*>/);
if (!appMatch) throw new Error('No se encontró <application> en el AndroidManifest');
const oldTag = appMatch[0];
let tag = oldTag;
if (/android:usesCleartextTraffic="true"/.test(tag)) {
  notes.push('OK   usesCleartextTraffic ya estaba activado');
} else {
  if (/android:usesCleartextTraffic="[^"]*"/.test(tag)) {
    tag = tag.replace(/android:usesCleartextTraffic="[^"]*"/, 'android:usesCleartextTraffic="true"');
  } else {
    tag = tag.replace('<application', '<application android:usesCleartextTraffic="true"');
  }
  notes.push('FIX  se activó usesCleartextTraffic');
}
if (/android:banner=/.test(tag)) {
  notes.push('OK   banner de TV ya estaba');
} else {
  tag = tag.replace('<application', '<application android:banner="@drawable/tv_banner"');
  notes.push('FIX  se agregó el banner de TV');
}
xml = xml.replace(oldTag, () => tag);

// 2) Que no exija pantalla táctil
['android.hardware.touchscreen', 'android.software.leanback'].forEach((name) => {
  if (xml.includes(`android:name="${name}"`)) {
    notes.push(`OK   uses-feature ${name}`);
  } else {
    xml = xml.replace(/<manifest\b[^>]*>/, (m) => `${m}\n  <uses-feature android:name="${name}" android:required="false"/>`);
    notes.push(`FIX  se agregó uses-feature ${name}`);
  }
});

// 3) Que aparezca en el menú de un TV box / Android TV
if (xml.includes('android.intent.category.LEANBACK_LAUNCHER')) {
  notes.push('OK   LEANBACK_LAUNCHER ya estaba');
} else {
  const at = xml.indexOf('android:name=".MainActivity"');
  const end = xml.indexOf('</activity>', at === -1 ? 0 : at);
  if (end === -1) throw new Error('No se encontró MainActivity en el AndroidManifest');
  const filter =
    '  <intent-filter>\n' +
    '        <action android:name="android.intent.action.MAIN"/>\n' +
    '        <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>\n' +
    '      </intent-filter>\n    ';
  xml = xml.slice(0, end) + filter + xml.slice(end);
  notes.push('FIX  se agregó LEANBACK_LAUNCHER');
}

fs.writeFileSync(mf, xml);

// 4) Banner de TV: copiar la imagen si falta
const dir = path.join(root, 'android', 'app', 'src', 'main', 'res', 'drawable');
const dest = path.join(dir, 'tv_banner.png');
if (fs.existsSync(dest)) {
  notes.push('OK   tv_banner.png ya estaba');
} else {
  fs.mkdirSync(dir, { recursive: true });
  fs.copyFileSync(path.join(root, 'assets', 'banner.png'), dest);
  notes.push('FIX  se copió tv_banner.png');
}

console.log('--- Revisión del AndroidManifest ---');
notes.forEach((n) => console.log(n));
console.log('--- Etiqueta <application> final ---');
console.log(xml.match(/<application\b[^>]*>/)[0]);
