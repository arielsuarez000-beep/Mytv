import React from 'react';
import { Image, Pressable, Text, View } from 'react-native';
import { C } from './theme';

export default function Card({ kind, item, width, onPress }) {
  const img = item.stream_icon || item.cover;
  const live = kind === 'live';
  const h = live ? Math.round(width * 0.62) : Math.round(width * 1.5);
  return (
    <Pressable onPress={onPress} style={{ width }}>
      <View
        style={{
          width,
          height: h,
          borderRadius: 8,
          backgroundColor: C.panel,
          overflow: 'hidden',
          alignItems: 'center',
          justifyContent: 'center',
          padding: live ? 8 : 0,
        }}
      >
        {img ? (
          <Image
            source={{ uri: img }}
            style={{ width: '100%', height: '100%' }}
            resizeMode={live ? 'contain' : 'cover'}
          />
        ) : (
          <Text style={{ color: C.dim, fontSize: 24, fontWeight: '700' }}>
            {(item.name || '?').trim().charAt(0).toUpperCase()}
          </Text>
        )}
      </View>
      <Text numberOfLines={2} style={{ color: C.text, fontSize: 12, marginTop: 6 }}>
        {item.name}
      </Text>
    </Pressable>
  );
}
