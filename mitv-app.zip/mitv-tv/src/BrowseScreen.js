import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { C } from './theme';
import { Pressable } from './Focus';
import Card from './Card';
import { makeOpen } from './open';
import { getCategoriesCached, getItemsCached } from './xtream';
import { setTvMode, useTv } from './tv';

const TABS = [
  ['live', 'TV en vivo'],
  ['vod', 'Películas'],
  ['series', 'Series'],
];

function Row({ creds, kind, cat, open, onSeeAll, z }) {
  const [items, setItems] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    getItemsCached(creds, kind, cat.category_id)
      .then((l) => alive && setItems(l))
      .catch(() => alive && setFailed(true));
    return () => {
      alive = false;
    };
  }, [kind, cat.category_id]);

  if (failed) return null;
  if (items && items.length === 0) return null;

  const cw = Math.round((kind === 'live' ? 132 : 112) * z);
  const preview = items ? items.slice(0, 30) : [];

  return (
    <View style={s.rowWrap}>
      <View style={s.rowHead}>
        <Text style={[s.rowTitle, { fontSize: 17 * z }]} numberOfLines={1}>
          {cat.category_name}
        </Text>
        <Pressable onPress={onSeeAll} hitSlop={8}>
          <Text style={[s.seeAll, { fontSize: 13 * z }]}>Ver todo ›</Text>
        </Pressable>
      </View>
      {!items ? (
        <View style={s.rowLoading}>
          <ActivityIndicator color={C.accent} />
        </View>
      ) : (
        <FlatList
          horizontal
          data={preview}
          keyExtractor={(i, n) => String(i.stream_id || i.series_id || n)}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 12 }}
          ItemSeparatorComponent={() => <View style={{ width: 10 }} />}
          renderItem={({ item, index }) => (
            <Card kind={kind} item={item} width={cw} onPress={() => open(item, items, index)} />
          )}
        />
      )}
    </View>
  );
}

export default function BrowseScreen({ creds, onPlay, onSeries, onGrid, onLogout }) {
  const [tab, setTab] = useState('live');
  const [cats, setCats] = useState(null);
  const [error, setError] = useState('');
  const tv = useTv();
  const z = tv ? 1.4 : 1;

  useEffect(() => {
    let alive = true;
    setCats(null);
    setError('');
    getCategoriesCached(creds, tab)
      .then((l) => alive && setCats(l))
      .catch((e) => alive && setError(e.message));
    return () => {
      alive = false;
    };
  }, [tab, creds]);

  const open = useMemo(() => makeOpen(creds, tab, onPlay, onSeries), [creds, tab, onPlay, onSeries]);

  return (
    <View style={s.root}>
      <View style={s.top}>
        <Image
          source={require('../assets/logo.png')}
          style={{ width: 40 * z, height: 40 * z, marginRight: 6 }}
          resizeMode="contain"
        />
        <Text style={[s.logo, { fontSize: 26 * z }]}>MiTV</Text>
        <View style={{ flex: 1 }} />
        <Pressable style={[s.pill, { marginRight: 10 }]} onPress={() => setTvMode(!tv)}>
          <Text style={s.pillText}>{tv ? 'Modo TV: sí' : 'Modo TV: no'}</Text>
        </Pressable>
        <Pressable
          style={s.pill}
          onPress={() => onGrid({ kind: tab, title: 'Buscar', search: true })}
        >
          <Text style={s.pillText}>Buscar</Text>
        </Pressable>
        <Pressable onPress={onLogout} hitSlop={10} style={{ marginLeft: 14 }}>
          <Text style={s.logout}>Salir</Text>
        </Pressable>
      </View>

      <View style={s.tabs}>
        {TABS.map(([k, label]) => (
          <Pressable
            key={k}
            onPress={() => setTab(k)}
            hasTVPreferredFocus={tab === k}
            style={[s.tab, tab === k && s.tabOn]}
          >
            <Text style={[s.tabText, { fontSize: 15 * z }, tab === k && s.tabTextOn]}>{label}</Text>
          </Pressable>
        ))}
      </View>

      {error ? (
        <Text style={s.msg}>{error}</Text>
      ) : !cats ? (
        <ActivityIndicator color={C.accent} style={{ marginTop: 40 }} />
      ) : cats.length === 0 ? (
        <Text style={s.msg}>No hay categorías disponibles.</Text>
      ) : (
        <FlatList
          key={tab}
          data={cats}
          keyExtractor={(c) => String(c.category_id)}
          initialNumToRender={tv ? 6 : 3}
          maxToRenderPerBatch={2}
          windowSize={tv ? 11 : 5}
          contentContainerStyle={{ paddingBottom: 30 }}
          renderItem={({ item }) => (
            <Row
              creds={creds}
              kind={tab}
              cat={item}
              open={open}
              z={z}
              onSeeAll={() =>
                onGrid({ kind: tab, title: item.category_name, catId: item.category_id })
              }
            />
          )}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingTop: 44 },
  top: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingBottom: 6 },
  logo: { color: C.accent, fontSize: 26, fontWeight: '800', letterSpacing: 0.5 },
  pill: {
    backgroundColor: C.panel,
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderWidth: 1,
    borderColor: C.line,
  },
  pillText: { color: C.text, fontSize: 13, fontWeight: '600' },
  logout: { color: C.dim, fontSize: 13 },
  tabs: { flexDirection: 'row', paddingHorizontal: 10, marginBottom: 6 },
  tab: { paddingVertical: 8, paddingHorizontal: 12, marginRight: 4 },
  tabOn: { borderBottomWidth: 2, borderBottomColor: C.accent },
  tabText: { color: C.dim, fontSize: 15, fontWeight: '600' },
  tabTextOn: { color: C.text },
  rowWrap: { marginTop: 14 },
  rowHead: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    marginBottom: 8,
  },
  rowTitle: { color: C.text, fontSize: 17, fontWeight: '700', flex: 1, marginRight: 10 },
  seeAll: { color: C.accent, fontSize: 13, fontWeight: '600' },
  rowLoading: { height: 110, justifyContent: 'center' },
  msg: { color: C.dim, textAlign: 'center', marginTop: 40, paddingHorizontal: 24 },
});
