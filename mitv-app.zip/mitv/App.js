import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, BackHandler, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { clearCreds, loadCreds, saveCreds } from './src/storage';
import { C } from './src/theme';
import SetupScreen from './src/SetupScreen';
import BrowseScreen from './src/BrowseScreen';
import SeriesScreen from './src/SeriesScreen';
import PlayerScreen from './src/PlayerScreen';

export default function App() {
  const [creds, setCreds] = useState(undefined); // undefined = cargando, null = sin sesión
  const [stack, setStack] = useState([]);

  useEffect(() => {
    loadCreds().then((c) => setCreds(c || null));
  }, []);

  const push = useCallback((s) => setStack((st) => [...st, s]), []);
  const pop = useCallback(() => setStack((st) => st.slice(0, -1)), []);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (stack.length) {
        pop();
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [stack, pop]);

  if (creds === undefined) {
    return (
      <View style={{ flex: 1, backgroundColor: C.bg, justifyContent: 'center' }}>
        <ActivityIndicator color={C.accent} size="large" />
      </View>
    );
  }

  if (!creds) {
    return (
      <>
        <StatusBar style="light" />
        <SetupScreen
          onDone={async (c) => {
            await saveCreds(c);
            setCreds(c);
          }}
        />
      </>
    );
  }

  const top = stack[stack.length - 1];

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style="light" />
      <View style={{ flex: 1, display: top ? 'none' : 'flex' }}>
        <BrowseScreen
          creds={creds}
          onPlay={(p) => push({ type: 'player', ...p })}
          onSeries={(s) => push({ type: 'series', item: s })}
          onLogout={async () => {
            await clearCreds();
            setStack([]);
            setCreds(null);
          }}
        />
      </View>
      {top && top.type === 'series' && (
        <SeriesScreen
          key={top.item.series_id}
          creds={creds}
          item={top.item}
          onBack={pop}
          onPlay={(p) => push({ type: 'player', ...p })}
        />
      )}
      {top && top.type === 'player' && (
        <PlayerScreen
          key={top.sources[0]}
          sources={top.sources}
          live={top.live}
          title={top.title}
          onBack={pop}
        />
      )}
    </View>
  );
}
