// Hace que MiTV aparezca también en el menú de aplicaciones de un TV box / Android TV,
// y que no exija pantalla táctil. Sigue funcionando igual en celulares.
const fs = require('fs');
const path = require('path');

function addFeature(manifest, name) {
  manifest['uses-feature'] = manifest['uses-feature'] || [];
  const exists = manifest['uses-feature'].some((f) => f.$ && f.$['android:name'] === name);
  if (!exists) {
    manifest['uses-feature'].push({ $: { 'android:name': name, 'android:required': 'false' } });
  }
}

function patchManifest(manifest) {
  addFeature(manifest, 'android.hardware.touchscreen');
  addFeature(manifest, 'android.software.leanback');

  const app = manifest.application && manifest.application[0];
  if (!app) return manifest;
  app.$['android:banner'] = '@drawable/tv_banner';

  const activities = app.activity || [];
  const main =
    activities.find((a) => a.$ && a.$['android:name'] === '.MainActivity') || activities[0];
  if (main) {
    main['intent-filter'] = main['intent-filter'] || [];
    const has = main['intent-filter'].some((f) =>
      (f.category || []).some(
        (c) => c.$ && c.$['android:name'] === 'android.intent.category.LEANBACK_LAUNCHER'
      )
    );
    if (!has) {
      main['intent-filter'].push({
        action: [{ $: { 'android:name': 'android.intent.action.MAIN' } }],
        category: [{ $: { 'android:name': 'android.intent.category.LEANBACK_LAUNCHER' } }],
      });
    }
  }
  return manifest;
}

module.exports = function withTv(config) {
  const { withAndroidManifest, withDangerousMod } = require('expo/config-plugins');

  config = withAndroidManifest(config, (cfg) => {
    patchManifest(cfg.modResults.manifest);
    return cfg;
  });

  config = withDangerousMod(config, [
    'android',
    async (cfg) => {
      const src = path.join(cfg.modRequest.projectRoot, 'assets', 'banner.png');
      const dir = path.join(cfg.modRequest.platformProjectRoot, 'app', 'src', 'main', 'res', 'drawable');
      fs.mkdirSync(dir, { recursive: true });
      fs.copyFileSync(src, path.join(dir, 'tv_banner.png'));
      return cfg;
    },
  ]);

  return config;
};
module.exports.patchManifest = patchManifest;
