# MiTV

Reproductor de canales en vivo, películas y series para listas Xtream. Se conecta directo desde el dispositivo, sin servidor propio. Un mismo APK sirve para celular y para TV box.

## Qué trae

- Menú estilo Netflix: filas por categoría con carruseles, «Ver todo» y buscador en toda la lista.
- TV en vivo: tocá para ver los controles, deslizá o usá los botones para cambiar de canal. Botón «Formato: TS / HLS» para elegir el que anda mejor.
- Pantalla completa: botón «Pantalla completa», o girá el celular.
- Modo TV: se maneja con el control remoto (flechas y OK). El elemento seleccionado se marca con un borde naranja.

## Instalarla en un TV box

1. En el TV box activá «Orígenes desconocidos» (o «Instalar apps desconocidas») en Ajustes → Seguridad.
2. Pasá el APK: desde un pendrive, o con la app «Downloader» escribiendo la dirección del APK en tu GitHub (Releases).
3. Abrí MiTV. Si la lista no se maneja bien con el control remoto, tocá «Modo TV» para activarlo.

## Cómo actualizar la app

1. En tu repositorio de GitHub, «Add file» → «Upload files» y subí este `mitv-app.zip` (reemplaza al anterior).
2. «Commit changes» y esperá el tilde verde en «Actions».
3. Bajá el `app-release.apk` nuevo desde «Releases» e instalalo encima de la versión anterior.
