# MiTV TV

Edición para televisores Android TV / Google TV y TV box, construida sobre React Native para TV
(react-native-tvos), que maneja la selección con el control remoto.

- Flechas: mover la selección (borde naranja). OK: abrir.
- Mirando un canal: flecha arriba/abajo cambia de canal; cualquier otra flecha u OK muestra los botones.
- Botón «atrás» del control: vuelve.
