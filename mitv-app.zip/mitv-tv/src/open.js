import { movieUrl } from './xtream';

// Devuelve la función que se ejecuta al tocar una tarjeta.
// En vivo pasa la lista completa para poder cambiar de canal.
export function makeOpen(creds, kind, onPlay, onSeries) {
  return (item, list, index) => {
    if (kind === 'live') {
      onPlay({ live: true, title: item.name, channels: list, index });
    } else if (kind === 'vod') {
      onPlay({
        live: false,
        title: item.name,
        sources: [movieUrl(creds, item.stream_id, item.container_extension)],
      });
    } else {
      onSeries(item);
    }
  };
}
