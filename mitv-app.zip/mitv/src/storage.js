import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'mitv_creds';

export async function loadCreds() {
  try {
    const s = await AsyncStorage.getItem(KEY);
    return s ? JSON.parse(s) : null;
  } catch {
    return null;
  }
}

export async function saveCreds(c) {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(c));
  } catch {}
}

export async function clearCreds() {
  try {
    await AsyncStorage.removeItem(KEY);
  } catch {}
}
