# MiTV

Reproductor de canales en vivo, películas y series para listas Xtream. Se conecta directo desde el celular, sin servidor propio.

## Cómo tener la app en el celular (Android)

1. Creá un repositorio en GitHub y subí todo el contenido de esta carpeta (incluida la carpeta `.github`).
2. Entrá a la pestaña **Actions** del repositorio y esperá a que termine "Construir APK" (tarda unos 10 a 15 minutos).
3. Entrá a **Releases**, descargá `app-release.apk` e instalalo en el celular (permití "instalar apps de origen desconocido" si te lo pide).
4. Abrí MiTV y cargá el servidor, usuario y contraseña de tu lista.

Cada vez que subas un cambio a la rama `main`, se genera un APK nuevo en Releases.

## Qué hace distinto en TV en vivo

- En Android pide primero el flujo directo `.ts`, y si falla usa `.m3u8`.
- Si la imagen se congela unos 9 segundos, recarga el canal sola.
