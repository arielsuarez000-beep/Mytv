// Si todos tus usuarios usan el mismo servidor, poné acá su dirección
// (por ejemplo 'http://servidor.com:8080') y la app la traerá cargada:
// cada persona solo tendrá que escribir su usuario y contraseña.
export const DEFAULT_SERVER = '';
