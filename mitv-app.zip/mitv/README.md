# MiTV

Reproductor de canales en vivo, películas y series para listas Xtream. Se conecta directo desde el celular, sin servidor propio.

## Qué trae

- Menú estilo Netflix: filas por categoría con carruseles, «Ver todo» y buscador en toda la lista.
- TV en vivo: tocá para ver los controles, deslizá (arriba/abajo o izquierda/derecha) o usá los botones para cambiar de canal. Abajo del video queda la lista de canales de la categoría.
- Pantalla completa: botón «Pantalla completa», o simplemente girá el celular. El botón «atrás» del celular sale de pantalla completa.
- En Android pide primero el flujo directo `.ts` y, si falla, usa `.m3u8`. Si la imagen se congela unos 9 segundos, recarga el canal sola.

## Cómo actualizar la app en el celular

1. En tu repositorio de GitHub, entrá a «Add file» → «Upload files» y subí este `mitv-app.zip` (reemplaza al anterior).
2. Tocá «Commit changes» y esperá el tilde verde en «Actions».
3. Bajá el `app-release.apk` nuevo desde «Releases» e instalalo encima de la versión anterior.
